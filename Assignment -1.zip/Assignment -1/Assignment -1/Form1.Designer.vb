﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        btnRightOpen = New Button()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        btnLeftOpen = New Button()
        btnRightClose = New Button()
        btnLeftClose = New Button()
        Label1 = New Label()
        TextBox1 = New TextBox()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btnRightOpen
        ' 
        btnRightOpen.Location = New Point(593, 572)
        btnRightOpen.Name = "btnRightOpen"
        btnRightOpen.Size = New Size(167, 29)
        btnRightOpen.TabIndex = 0
        btnRightOpen.Text = "Open The Door"
        btnRightOpen.UseVisualStyleBackColor = True
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.stage1_removebg_preview
        PictureBox1.Location = New Point(90, 105)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(180, 442)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = My.Resources.Resources.stage1_removebg_preview
        PictureBox2.Location = New Point(581, 105)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(179, 442)
        PictureBox2.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox2.TabIndex = 3
        PictureBox2.TabStop = False
        ' 
        ' btnLeftOpen
        ' 
        btnLeftOpen.Location = New Point(103, 572)
        btnLeftOpen.Name = "btnLeftOpen"
        btnLeftOpen.Size = New Size(167, 29)
        btnLeftOpen.TabIndex = 4
        btnLeftOpen.Text = "Open The Door"
        btnLeftOpen.UseVisualStyleBackColor = True
        ' 
        ' btnRightClose
        ' 
        btnRightClose.Location = New Point(593, 623)
        btnRightClose.Name = "btnRightClose"
        btnRightClose.Size = New Size(167, 29)
        btnRightClose.TabIndex = 5
        btnRightClose.Text = "Close The Door"
        btnRightClose.UseVisualStyleBackColor = True
        ' 
        ' btnLeftClose
        ' 
        btnLeftClose.Location = New Point(103, 623)
        btnLeftClose.Name = "btnLeftClose"
        btnLeftClose.Size = New Size(167, 29)
        btnLeftClose.TabIndex = 6
        btnLeftClose.Text = "Close The Door"
        btnLeftClose.UseVisualStyleBackColor = True
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe Print", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(254, 27)
        Label1.Name = "Label1"
        Label1.Size = New Size(339, 61)
        Label1.TabIndex = 7
        Label1.Text = "Pick a door wisely"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(319, 269)
        TextBox1.Multiline = True
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(211, 98)
        TextBox1.TabIndex = 8
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8.0F, 20.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(835, 675)
        Controls.Add(TextBox1)
        Controls.Add(Label1)
        Controls.Add(btnLeftClose)
        Controls.Add(btnRightClose)
        Controls.Add(btnLeftOpen)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(btnRightOpen)
        Name = "Form1"
        Text = "Lady Or the tiger"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnRightOpen As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btnLeftOpen As Button
    Friend WithEvents btnRightClose As Button
    Friend WithEvents btnLeftClose As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents TextBox1 As TextBox

End Class
