﻿Public Class Form1

    Dim leftDoorOpen As Boolean = False
    Dim rightDoorOpen As Boolean = False

    Private Sub btnRightOpen_Click(sender As Object, e As EventArgs) Handles btnRightOpen.Click
        rightDoorOpen = True
        updateDoorStatus()
    End Sub

    Private Sub btnRightClose_Click(sender As Object, e As EventArgs) Handles btnRightClose.Click
        rightDoorOpen = False
        updateDoorStatus()
    End Sub

    Private Sub btnLeftOpen_Click(sender As Object, e As EventArgs) Handles btnLeftOpen.Click
        leftDoorOpen = True
        updateDoorStatus()
    End Sub

    Private Sub btnLeftClose_Click(sender As Object, e As EventArgs) Handles btnLeftClose.Click
        leftDoorOpen = False
        updateDoorStatus()
    End Sub

    Private Sub updateDoorStatus()
        If leftDoorOpen Then
            PictureBox1.Image = My.Resources.Resources.stage5_removebg_preview
            TextBox1.Text = "Door Left is now Open."
        Else
            PictureBox1.Image = My.Resources.Resources.stage1_removebg_preview
            TextBox1.Text = "Door Left is now Close."
        End If

        If rightDoorOpen Then
            PictureBox2.Image = My.Resources.Resources.stage5_removebg_preview
            TextBox1.Text &= vbCrLf & "Door Right is now Open."
        Else
            PictureBox2.Image = My.Resources.Resources.stage1_removebg_preview
            TextBox1.Text &= vbCrLf & "Door Right is now Close."
        End If
    End Sub
End Class
