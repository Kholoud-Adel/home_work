﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Const hourlyRate As Decimal = 9.5D

        Dim weeklyPay1 As Decimal
        Dim weeklyPay2 As Decimal
        Dim weeklyPay3 As Decimal
        Dim weeklyPay4 As Decimal
        Dim totalPay As Decimal

        Decimal.TryParse(TextBox8.Text, weeklyPay1)
        weeklyPay1 = weeklyPay1 * hourlyRate
        TextBox12.Text = weeklyPay1.ToString("C")

        Decimal.TryParse(TextBox7.Text, weeklyPay2)
        weeklyPay2 = weeklyPay2 * hourlyRate
        TextBox11.Text = weeklyPay2.ToString("C")

        Decimal.TryParse(TextBox6.Text, weeklyPay3)
        weeklyPay3 = weeklyPay3 * hourlyRate
        TextBox10.Text = weeklyPay3.ToString("C")

        Decimal.TryParse(TextBox5.Text, weeklyPay4)
        weeklyPay4 = weeklyPay4 * hourlyRate
        TextBox9.Text = weeklyPay4.ToString("C")

        totalPay = weeklyPay1 + weeklyPay2 + weeklyPay3 + weeklyPay4

        TextBox13.Text = totalPay.ToString("C")
    End Sub
End Class
