﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        PictureBox1 = New PictureBox()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        TextBox3 = New TextBox()
        TextBox4 = New TextBox()
        btnCalculate = New Button()
        TextBox5 = New TextBox()
        TextBox6 = New TextBox()
        TextBox7 = New TextBox()
        TextBox8 = New TextBox()
        TextBox9 = New TextBox()
        TextBox10 = New TextBox()
        TextBox11 = New TextBox()
        TextBox12 = New TextBox()
        TextBox13 = New TextBox()
        Label5 = New Label()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Segoe Print", 10.8F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(509, 41)
        Label1.Name = "Label1"
        Label1.Padding = New Padding(4)
        Label1.Size = New Size(264, 39)
        Label1.TabIndex = 0
        Label1.Text = "Paytoll Accounting System"
        ' 
        ' PictureBox1
        ' 
        PictureBox1.Image = My.Resources.Resources.image_removebg_preview__4_
        PictureBox1.Location = New Point(25, 18)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(125, 62)
        PictureBox1.TabIndex = 1
        PictureBox1.TabStop = False
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe Print", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(25, 118)
        Label2.Name = "Label2"
        Label2.Padding = New Padding(4)
        Label2.Size = New Size(142, 34)
        Label2.TabIndex = 2
        Label2.Text = "Employee Name"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe Print", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(317, 118)
        Label3.Name = "Label3"
        Label3.Padding = New Padding(4)
        Label3.Size = New Size(127, 34)
        Label3.TabIndex = 3
        Label3.Text = "Hours Worked"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe Print", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(539, 118)
        Label4.Name = "Label4"
        Label4.Padding = New Padding(4)
        Label4.Size = New Size(108, 34)
        Label4.TabIndex = 4
        Label4.Text = "Weekly Pay"
        ' 
        ' TextBox1
        ' 
        TextBox1.Font = New Font("Segoe Print", 9.0F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        TextBox1.Location = New Point(25, 177)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(202, 34)
        TextBox1.TabIndex = 5
        ' 
        ' TextBox2
        ' 
        TextBox2.Font = New Font("Segoe Print", 9.0F)
        TextBox2.Location = New Point(25, 236)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(202, 34)
        TextBox2.TabIndex = 6
        ' 
        ' TextBox3
        ' 
        TextBox3.Font = New Font("Segoe Print", 9.0F)
        TextBox3.Location = New Point(25, 353)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(202, 34)
        TextBox3.TabIndex = 7
        ' 
        ' TextBox4
        ' 
        TextBox4.Font = New Font("Segoe Print", 9.0F)
        TextBox4.Location = New Point(25, 295)
        TextBox4.Name = "TextBox4"
        TextBox4.Size = New Size(202, 34)
        TextBox4.TabIndex = 8
        ' 
        ' btnCalculate
        ' 
        btnCalculate.Font = New Font("Rockwell", 10.8F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        btnCalculate.Location = New Point(25, 409)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(179, 32)
        btnCalculate.TabIndex = 9
        btnCalculate.Text = "Calculate"
        btnCalculate.UseVisualStyleBackColor = True
        ' 
        ' TextBox5
        ' 
        TextBox5.Font = New Font("Segoe Print", 9.0F)
        TextBox5.Location = New Point(317, 295)
        TextBox5.Name = "TextBox5"
        TextBox5.Size = New Size(115, 34)
        TextBox5.TabIndex = 13
        ' 
        ' TextBox6
        ' 
        TextBox6.Font = New Font("Segoe Print", 9.0F)
        TextBox6.Location = New Point(317, 353)
        TextBox6.Name = "TextBox6"
        TextBox6.Size = New Size(115, 34)
        TextBox6.TabIndex = 12
        ' 
        ' TextBox7
        ' 
        TextBox7.Font = New Font("Segoe Print", 9.0F)
        TextBox7.Location = New Point(317, 236)
        TextBox7.Name = "TextBox7"
        TextBox7.Size = New Size(115, 34)
        TextBox7.TabIndex = 11
        ' 
        ' TextBox8
        ' 
        TextBox8.Font = New Font("Segoe Print", 9.0F)
        TextBox8.Location = New Point(317, 177)
        TextBox8.Name = "TextBox8"
        TextBox8.Size = New Size(115, 34)
        TextBox8.TabIndex = 10
        ' 
        ' TextBox9
        ' 
        TextBox9.Font = New Font("Segoe Print", 9.0F)
        TextBox9.Location = New Point(520, 295)
        TextBox9.Name = "TextBox9"
        TextBox9.Size = New Size(182, 34)
        TextBox9.TabIndex = 17
        ' 
        ' TextBox10
        ' 
        TextBox10.Font = New Font("Segoe Print", 9.0F)
        TextBox10.Location = New Point(520, 353)
        TextBox10.Name = "TextBox10"
        TextBox10.Size = New Size(182, 34)
        TextBox10.TabIndex = 16
        ' 
        ' TextBox11
        ' 
        TextBox11.Font = New Font("Segoe Print", 9.0F)
        TextBox11.Location = New Point(520, 236)
        TextBox11.Name = "TextBox11"
        TextBox11.Size = New Size(182, 34)
        TextBox11.TabIndex = 15
        ' 
        ' TextBox12
        ' 
        TextBox12.Font = New Font("Segoe Print", 9.0F)
        TextBox12.Location = New Point(520, 177)
        TextBox12.Name = "TextBox12"
        TextBox12.Size = New Size(182, 34)
        TextBox12.TabIndex = 14
        ' 
        ' TextBox13
        ' 
        TextBox13.Font = New Font("Segoe Print", 9.0F)
        TextBox13.Location = New Point(520, 409)
        TextBox13.Name = "TextBox13"
        TextBox13.Size = New Size(182, 34)
        TextBox13.TabIndex = 18
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("Segoe Print", 9.0F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(401, 407)
        Label5.Name = "Label5"
        Label5.Padding = New Padding(4)
        Label5.Size = New Size(93, 34)
        Label5.TabIndex = 19
        Label5.Text = "Total Pay"
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8.0F, 20.0F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(800, 467)
        Controls.Add(Label5)
        Controls.Add(TextBox13)
        Controls.Add(TextBox9)
        Controls.Add(TextBox10)
        Controls.Add(TextBox11)
        Controls.Add(TextBox12)
        Controls.Add(TextBox5)
        Controls.Add(TextBox6)
        Controls.Add(TextBox7)
        Controls.Add(TextBox8)
        Controls.Add(btnCalculate)
        Controls.Add(TextBox4)
        Controls.Add(TextBox3)
        Controls.Add(TextBox2)
        Controls.Add(TextBox1)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(PictureBox1)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Payraoll Accounting System"
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents Label5 As Label

End Class
