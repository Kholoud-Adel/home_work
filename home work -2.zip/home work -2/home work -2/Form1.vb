﻿Public Class Form1
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Const decSalesTaxRate As Decimal = 0.06D

        Dim decSalesTaxAmount As Decimal
        Dim decFinalPrice As Decimal
        Dim decPurchasePrice As Decimal

        Decimal.TryParse(TextBox1.Text, decPurchasePrice)

        decSalesTaxAmount = decPurchasePrice * decSalesTaxRate

        decFinalPrice = decPurchasePrice + decSalesTaxAmount

        TextBox2.Text = decSalesTaxAmount.ToString("C")

        TextBox3.Text = decFinalPrice.ToString("C")
    End Sub
End Class
