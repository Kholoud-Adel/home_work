﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Label1 = New Label()
        Label2 = New Label()
        TextBox1 = New TextBox()
        TextBox2 = New TextBox()
        Label3 = New Label()
        TextBox3 = New TextBox()
        Label4 = New Label()
        btnCalculate = New Button()
        SuspendLayout()
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Elephant", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(52, 27)
        Label1.Name = "Label1"
        Label1.Size = New Size(253, 26)
        Label1.TabIndex = 0
        Label1.Text = "Sales Tax Calcualtion"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(27, 91)
        Label2.Name = "Label2"
        Label2.Size = New Size(126, 23)
        Label2.TabIndex = 1
        Label2.Text = "purchase price"
        ' 
        ' TextBox1
        ' 
        TextBox1.Location = New Point(168, 91)
        TextBox1.Name = "TextBox1"
        TextBox1.Size = New Size(146, 27)
        TextBox1.TabIndex = 2
        ' 
        ' TextBox2
        ' 
        TextBox2.Location = New Point(168, 143)
        TextBox2.Name = "TextBox2"
        TextBox2.Size = New Size(146, 27)
        TextBox2.TabIndex = 4
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.Location = New Point(27, 143)
        Label3.Name = "Label3"
        Label3.Size = New Size(126, 23)
        Label3.TabIndex = 3
        Label3.Text = "purchase price"
        ' 
        ' TextBox3
        ' 
        TextBox3.Location = New Point(168, 203)
        TextBox3.Name = "TextBox3"
        TextBox3.Size = New Size(146, 27)
        TextBox3.TabIndex = 6
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.Location = New Point(27, 203)
        Label4.Name = "Label4"
        Label4.Size = New Size(126, 23)
        Label4.TabIndex = 5
        Label4.Text = "purchase price"
        ' 
        ' btnCalculate
        ' 
        btnCalculate.BackColor = Color.LightGoldenrodYellow
        btnCalculate.Location = New Point(107, 254)
        btnCalculate.Name = "btnCalculate"
        btnCalculate.Size = New Size(128, 32)
        btnCalculate.TabIndex = 7
        btnCalculate.Text = "Calculate"
        btnCalculate.UseVisualStyleBackColor = False
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(8F, 20F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.Info
        ClientSize = New Size(340, 313)
        Controls.Add(btnCalculate)
        Controls.Add(TextBox3)
        Controls.Add(Label4)
        Controls.Add(TextBox2)
        Controls.Add(Label3)
        Controls.Add(TextBox1)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Name = "Form1"
        Text = "Sales Tax Calcualtion"
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents btnCalculate As Button

End Class
